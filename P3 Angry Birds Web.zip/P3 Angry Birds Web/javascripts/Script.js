

class Personaje{
  
  constructor(nombre,forma,div,posicionX,posicionY,image){
		this.nombre=nombre;
		this.forma=forma;
		this.image=image;
		this.x=posicionX;
		this.y=posicionY;
		this.div=div;

		this.DisplayImg=function(){

			document.getElementById(this.div).innerHTML=this.image; 
			document.getElementById(this.div).style.left =this.x; 
			document.getElementById(this.div).style.top =this.y; 
		}
		this.ObtDetalles=function(info5,info6){

            document.getElementById("info").innerHTML=
            '<section id="Info-Square">'+
            '<h1 id="Detalles">Detalles</h1>'+
            '<h1 id="info1">Nombre: '+this.nombre+'</h1>'+
            '<h1 id="info2">Forma: '+ this.forma + '</h1>'+
            '<h1 id="info3">Posicion X: '+ this.x + '</h1>'+
            '<h1 id="info4">Posicion Y: '+ this.y + '</h1>'+
            '<h1 id="info5">Habilidad(Ave),Fortaleza(Cerdo):'+'<p>'+ info5 +'</p>' + '</h1>'+
            '<h1 id="info6">Masa(Ave),Puntos(Cerdo):'+'<p>'+ info6 +'</p>' + '</h1>'+
            '</section>';	
		}
	}
}

class Ave extends Personaje{

	constructor(nombre,forma,div,posicionX,posicionY,image,habilidad,masa){
	super (nombre,forma,div,posicionX,posicionY,image);
	this.habilidad=habilidad;
	this.masa=masa;
	this.Volar=function(){

        document.getElementById("info").innerHTML=
        '<section id="Mensaje">'+ '<h1 id="accion">Volando!!</h1>'+
        '</section>'
	}

  }    
}


class Pig extends Personaje{
	constructor(nombre,forma,div,posicionX,posicionY,image,fortaleza,puntos){
	super (nombre,forma,div,posicionX,posicionY,image);
	this.fortaleza=fortaleza;
	this.puntos=puntos;
	this.Morir=function(){

		 document.getElementById("info").innerHTML=
        '<section id="Mensaje">'+ '<h1 id="accion">Me Mataste!! :(</h1>'+
        '</section>'
	}
 }
}

                                 /************Objetos**************/
const Ave1=new Ave("Red","Ave","Ave1-div","10rem","22rem",'<img src="images/red.png" height="120" width="120">',"Enojarse hasta golpear","Sepa:)");
const Ave2=new Ave("Stella","Ave","Ave2-div","10rem","0rem",'<img src="images/stella.png" height="120" width="120">',"Atrapar objetos en burbujas","Sepa:)");
const Ave3=new Ave("Bubbles","Ave","Ave3-div","24rem","30rem",'<img src="images/bubbles.png" height="120" width="120">',"Inflarse","Sepa:)");

const Pig1=new Pig("Frank","Cerdo","Pig1-div","25rem","22rem",'<img src="images/pig1.png" height="95" width="95">',"Golpear Fuerte","200");
const Pig2=new Pig("Zombie Pig","Cerdo","Pig2-div","34rem","4.3rem",'<img src="images/pig2.png" height="95" width="95">',"Golpear Fuerte","120");
const Pig3=new Pig("Junior","Cerdo","Pig3-div","23rem","30rem",'<img src="images/pig3.png" height="120" width="120">',"Golpear Fuerte","60");

Ave1.DisplayImg();
Ave2.DisplayImg();
Ave3.DisplayImg();

Pig1.DisplayImg();
Pig2.DisplayImg();
Pig3.DisplayImg();


