
var flag=0;
var temp=0;



function Crear_BotonesBorrar(){
  /****** Insertar el Boton en el Elemento de la lista ******/
var NodoBotones = document.getElementsByTagName("li");

for (var i = 0; i < NodoBotones.length; i++) {
  var button = document.createElement("BUTTON");
  var text = document.createTextNode("x");
  button.className = "Borrar";
  button.value=i;
  button.appendChild(text);
  NodoBotones[i].appendChild(button);
}

}

function Crear_BotonesEditar(){
		/******   Editar Boton ******/
var NodoBotones_Editar = document.getElementsByTagName("li");

for (var i = 0; i < NodoBotones_Editar.length; i++) {
  var button = document.createElement("BUTTON");
  var text = document.createTextNode("Edit");
  button.className = "Editar";
  button.value=i;
  button.appendChild(text);
  NodoBotones_Editar[i].appendChild(button);
}

}

function Borrar()
{
        /******  Borrar Elemneto ******/
var Borrar = document.getElementsByClassName("Borrar");

for (var i = 0; i < Borrar.length; i++) {
   /*Funcion que permite eliminar elemento de la lista*/
  Borrar[i].onclick = function() {    /*Agrega la funcion al Elemento*/     
    const div = this.parentElement;
    div.parentElement.removeChild(div);
  }
}
}

var Lista = document.querySelector('ul');
Lista.addEventListener('click', function(ev) {
  if (ev.target.tagName === 'LI') {
    ev.target.classList.toggle('checked');
  }
}, false);


function Editar(){

var Editar = document.getElementsByClassName("Editar");
for (var i = 0; i < Editar.length; i++) {
   /*Funcion que permite eliminar elemento de la lista*/
    Editar[i].onclick = function() {    /*Agrega la funcion al Elemento*/
     temp=this.value;
     var a =document.getElementsByClassName("Elemento")[temp].textContent; /*Guardar Texto*/
     document.getElementById("List-Input").value=a;
     document.getElementById("List-Input").select();
     flag=1;
  }

}
}


function Agregar(){
    var i=0;
    var Lista=document.createElement('li');
	var texto_a=document.createElement('H1');
    texto_a.className = "Elemento";
    /*Obtener el valor de Entrada que ingreso el usuario*/
	var Valor_Entrada= document.getElementById("List-Input").value;
    var NuevoTexto= document.createTextNode(Valor_Entrada);

    if(flag==0){
    /*Crear un Nuevo elemento en la Lista*/
    Lista.appendChild(texto_a);
    texto_a.appendChild(NuevoTexto);
    }

    if(Valor_Entrada==''){
    	alert("Tienes que Escribir algo");
    }
    else
    {
    	if(flag==0){
    	document.getElementById("List").appendChild(Lista);
        }
        else{

           document.getElementsByClassName("Elemento")[temp].textContent=Valor_Entrada;
           flag=0;
           console.log(flag);
        }
    }
   
    document.getElementById("List-Input").value = "";        /*Borrar el texto del Input*/

      var Editar_a = document.getElementsByClassName("Editar");
      i=Editar_a.length;
      var button = document.createElement("BUTTON");
      var text_borrar = document.createTextNode("X");
      var button_Editar = document.createElement("BUTTON");
      var text_editar = document.createTextNode("Edit");
	 
	  button.className = "Borrar";
	  button.value=i;
	  button_Editar.className = "Editar";
	  button_Editar.value=i;
	
	  button.appendChild(text_borrar);
	  button_Editar.appendChild(text_editar);
	  Lista.appendChild(button);
	  Lista.appendChild(button_Editar);
      Borrar();
      Editar();
      
}

Crear_BotonesBorrar();
Crear_BotonesEditar();
Editar();
Borrar();